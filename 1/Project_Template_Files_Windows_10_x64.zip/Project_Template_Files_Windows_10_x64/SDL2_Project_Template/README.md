# SDL2_Project_Template
 Template project using cmake for programs using SDL2, SDL2_image, and SDL_ttf, with provisons for windows dirent using https://github.com/tronkko/dirent
 kissfft is also included to ease development of some signal processing applications

 It should work on windows, mac, and linux
